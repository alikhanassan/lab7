const removeHelloWorld = document.querySelector("h1");
removeHelloWorld.remove();

const body = document.getElementsByTagName("body")[0];

const h1_1 = document.createElement("h1");
h1_1.innerHTML = "Lab7 Assignment";
h1_1.style.color = "blue";

body.appendChild(h1_1);
body.appendChild(document.createElement("hr"));

const h2_1 = document.createElement("h2");
h2_1.innerHTML = "Task";
h2_1.setAttribute("style", "color: red");

body.appendChild(h2_1);

const p_1 = document.createElement("p");
p_1.innerHTML =
  "In this task you have to reproduce this HTML page as is using <b>only</b> JavaScript. The task will be evaluated on the basis of the following DOM manipulation techniques:";

body.appendChild(p_1);

const ul_1 = document.createElement("ul");

const li_1 = document.createElement("li");
li_1.innerHTML = "find elements in the DOM (<b>5 points</b>);";
li_1.classList.add("even");
li_1.setAttribute("style", "color: green");

const li_2 = document.createElement("li");
li_2.innerHTML = "create/add/remove elements (<b>5 points</b>);";
li_2.classList.add("odd");
li_2.setAttribute("style", "color: purple");

const li_3 = document.createElement("li");
li_3.innerHTML = "change content of the elements (<b>5 points</b>);";
li_3.classList.add("even");
li_3.setAttribute("style", "color: green");

const li_4 = document.createElement("li");
li_4.innerHTML = "change styles of the elements (<b>5 points</b>);";
li_4.classList.add("odd");
li_4.setAttribute("style", "color: purple");

const li_5 = document.createElement("li");
li_5.innerHTML = "change attributes of the elements (<b>5 points</b>);";
li_5.classList.add("even");
li_5.setAttribute("style", "color: green");

const li_6 = document.createElement("li");
li_6.innerHTML = "change classes of the elements (<b>5 points</b>).";
li_6.classList.add("odd");
li_6.setAttribute("style", "color: purple");

ul_1.appendChild(li_1);
ul_1.appendChild(li_2);
ul_1.appendChild(li_3);
ul_1.appendChild(li_4);
ul_1.appendChild(li_5);
ul_1.appendChild(li_6);

body.appendChild(ul_1);
body.appendChild(document.createElement("hr"));

const h2_2 = document.createElement("h2");
h2_2.innerHTML = "Submission";
h2_2.setAttribute("style", "color: red");

body.appendChild(h2_2);

const p_2 = document.createElement("p");
p_2.innerHTML = "To submit your work, follow these instructions:";

body.appendChild(p_2);

const ul_2 = document.createElement("ul");

const li_7 = document.createElement("li");
li_7.innerHTML =
  "Create a new repository on Github, named <b>lab7</b> (<b>1 point</b>).";
li_7.classList.add("even");
li_7.setAttribute("style", "color: green");

const li_8 = document.createElement("li");
li_8.innerHTML =
  "Clone this repository to your local machine and work inside it.";
li_8.classList.add("odd");
li_8.setAttribute("style", "color: purple");

const li_9 = document.createElement("li");
li_9.innerHTML =
  'Create a new HTML file, called <b>index.html</b>, which has only one &lt;h1&gt; tag with "Hello, World!" message (<b>1 point</b>).';
li_9.classList.add("even");
li_9.setAttribute("style", "color: green");

const li_10 = document.createElement("li");
li_10.innerHTML =
  "Create a new JavaScript file, called <b>main.js</b>, which must contain your program (assignment) described above (<b>1 point</b>).";
li_10.classList.add("odd");
li_10.setAttribute("style", "color: purple");

const li_11 = document.createElement("li");
li_11.innerHTML =
  "Link this <b>main.js</b> file to your <b>index.html</b> file (Note: place your script at the end of the <b>body</b> section).";
li_11.classList.add("even");
li_11.setAttribute("style", "color: green");

const li_12 = document.createElement("li");
li_12.innerHTML =
  "Write a JavaScript program in <b>main.js</b> to make your <b>index.html</b> look identical to this HTML file (<b>5 points</b>).";
li_12.classList.add("odd");
li_12.setAttribute("style", "color: purple");

const li_13 = document.createElement("li");
li_13.innerHTML =
  "After you finish your work, submit it to the Github (<b>2 points</b>).";
li_13.classList.add("even");
li_13.setAttribute("style", "color: green");

ul_2.appendChild(li_7);
ul_2.appendChild(li_8);
ul_2.appendChild(li_9);
ul_2.appendChild(li_10);
ul_2.appendChild(li_11);
ul_2.appendChild(li_12);
ul_2.appendChild(li_13);

body.appendChild(ul_2);
body.appendChild(document.createElement("hr"));
